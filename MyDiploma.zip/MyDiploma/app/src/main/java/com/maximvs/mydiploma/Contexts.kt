package com.maximvs.mydiploma

data class Contexts(
    val groupings: List<String>
)