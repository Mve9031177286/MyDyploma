package com.maximvs.mydiploma

data class Thumbnail(
    val alt_text: String,
    val height: Int,
    val lqip: String,
    val width: Int
)