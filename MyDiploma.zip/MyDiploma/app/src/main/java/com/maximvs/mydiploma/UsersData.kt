package com.maximvs.mydiploma

data class UsersData(
    val config: Config,
    val `data`: List<Data>,
    val info: Info,
    val pagination: Pagination
)