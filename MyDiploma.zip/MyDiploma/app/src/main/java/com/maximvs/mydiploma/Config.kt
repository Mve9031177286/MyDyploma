package com.maximvs.mydiploma

data class Config(
    val iiif_url: String,
    val website_url: String
)