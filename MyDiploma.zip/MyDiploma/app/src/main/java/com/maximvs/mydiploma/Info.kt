package com.maximvs.mydiploma

data class Info(
    val license_links: List<String>,
    val license_text: String,
    val version: String
)